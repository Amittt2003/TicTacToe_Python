class Point:
    def __init__(self, xCord, yCord):
        self.xCord = xCord
        self.yCord = yCord

    def getX(self):
        return self.xCord

    def getY(self):
        return self.yCord
